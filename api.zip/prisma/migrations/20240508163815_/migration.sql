-- AlterTable
ALTER TABLE `selfevaluation` ADD COLUMN `active` BOOLEAN NULL DEFAULT true;
